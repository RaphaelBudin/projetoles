Pendências ou ajustes póstumos por página:

# Cadastro de Livros
- [ ] Forçar apenas duas casas decimais: Altura, Largura, Profundidade
- [x] Criar sistema de tags em Categorias e Grupo de Precificação (https://dev.to/0shuvo0/lets-create-an-add-tags-input-with-react-js-d29)
- [ ] Fazer sistema de pesquisa de Autores cadastrados (mockados a princípio)
- [ ] Cadastrar o livro nas Props
    - [ ] Mostrar na Página Inicial em Livros Cadastrados 

# Navbar
- [x] Remover aba de cadastros
# App
- [ ] Refatorar itensCarrinho e Total carrinho para => Carrinho

# Carrinho
- [ ] Agregar os livros iguais
- [ ] Opção de alterar quantidade
- [ ] Inserir campo de CEP e adicionar ao valor
    - [ ] Integração com VIACEP

# Pagamento
- [ ] Validar número de cartão de crédito

# Processamento
- [ ] A tag img dos livros está invadindo a div abaixo, verificar
- [ ] useNavigate para página detalheLivro, passando o livro via props

# Geral
- [ ] Fazer sistema de cadastro de usuários
- [ ] Usar LocalStorage para persistir produtos adicionados ao carrinho
- [ ] Fazer sistema de pesquisa funcionar
