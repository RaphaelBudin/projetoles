import "./Header.css";
import CustomNavbar from "./CustomNavbar";

export default function Header() {
  return (
      <CustomNavbar/>
  );
}
