import './Dimensoes.css';

export default function Dimensoes(){
    return <h1> DIMENSÕES </h1>
}