import CustomNavbar from '../../components/Header/CustomNavbar';
import './PageCadastroCliente.css';

export default function PageCadastroCliente(){
    return (
        <>
            <CustomNavbar/>
        </>
    );
}