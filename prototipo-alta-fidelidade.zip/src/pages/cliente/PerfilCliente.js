import './PerfilCliente.css';

export default function PerfilCliente(){
    return <h1> Página PerfilCliente </h1>
}