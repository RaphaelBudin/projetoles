import './CadastroCategoria.css';

export default function CadastroCategoria(){
    return <h1> Página CadastroCategoria </h1>
}