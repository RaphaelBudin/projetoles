import './DetalheCategoria.css';

export default function DetalheCategoria(){
    return <h1> Página DetalheCategoria </h1>
}