import './DetalheVenda.css';

export default function DetalheVenda(){
    return <h1> Página DetalheVenda </h1>
}