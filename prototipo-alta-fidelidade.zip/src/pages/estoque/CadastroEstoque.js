import './CadastroEstoque.css';

export default function CadastroEstoque(){
    return <h1> Página CadastroEstoque</h1>
}